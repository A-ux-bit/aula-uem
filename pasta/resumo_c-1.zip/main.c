//biblioteca
#include <stdio.h>
//#include <conio.h>
//#include <math.h>

int main (){

  int a, f,resultado,x;
  float b = 1.2;
  char c = 'F';
  char d[10] = "aleatório"; 

  /*printf("Digite o valor de A:\n");
  scanf("%d", &a);
  
  printf("Digite o valor de F: \n");
  scanf("%d",&f);
  
  resultado = a + f;
      
  printf("O valor da soma é: %d", resultado);
  
  if (resultado >10) {
      printf("Resultado é maior que 10\n");
      
  }
  else if (resultado<10) {
      printf("Resultado é menor que 10\n");
  }
  else {
      printf("O resultado é igual a 10\n");
  }*/
  
  for (x=0; x<10; x++) {
      printf("O valor de x é: %d\n",x);
      
  }
      while(x>0){
          
          x=x-1;
          printf("O valor de é:%d\n",x);
      }
      return 0;
} //fim da programa 
